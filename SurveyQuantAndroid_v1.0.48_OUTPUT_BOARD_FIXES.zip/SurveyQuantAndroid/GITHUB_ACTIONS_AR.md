# تشغيل بناء SurveyQuant APK من GitHub Actions

1. ارفع محتويات هذا المشروع إلى Repository على GitHub.
2. افتح تبويب **Actions**.
3. اختر **Build SurveyQuant APK**.
4. اضغط **Run workflow**.
5. بعد انتهاء البناء افتح الـRun الناجح.
6. من قسم **Artifacts** حمّل **SurveyQuant-APK**.
7. داخل الملف المضغوط ستجد:
   - `SurveyQuant.apk` وهو ملف الـAPK القابل للتثبيت.
   - `SurveyQuant-debug.apk` نسخة مطابقة للاختبار.
   - `SHA256SUMS.txt` للتحقق من سلامة الملف.

## ملاحظة مهمة
هذه النسخة تستخدم Debug signing حتى يكون الـAPK الناتج قابلًا للتثبيت مباشرة بدون إعداد Keystore خاص.
عند تجهيز نسخة توزيع نهائية للعملاء، يجب إنشاء Keystore ثابت وتوقيع Release APK به حتى يمكن تحديث التطبيق مستقبلًا بنفس مفتاح التوقيع.

المشروع مضبوط على:
- compileSdk 33
- targetSdk 33
- minSdk 23
- Java 17
- Gradle 8.10.2
